insert into Trains values (1000,'BLRMYS','BLRMYS1','Bangalore - Mysore');
insert into Trains values (1001,'BLRCHE','BLRCHE2','Bangalore - Chennai');
insert into Trains values (1002,'BLRHYD','BLRHYD3','Bangalore - Hyderabad');
insert into Trains values (1003,'JAICAL','JAICAL4','Jaipur - Calcutta');
insert into Timing values (1000,'2024-04-30 16:30:00','2024-04-30 16:40:00');
insert into Timing values (1001,'2024-05-30 16:30:00','2024-05-30 16:40:00');
insert into Timing values (1002,'2024-06-30 16:30:00','2024-06-30 16:40:00');
insert into Timing values (1003,'2024-07-30 16:30:00','2024-07-30 16:40:00');
